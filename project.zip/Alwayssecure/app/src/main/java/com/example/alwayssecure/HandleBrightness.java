package com.example.alwayssecure;

import android.app.Activity;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.EditText;

public class HandleBrightness {

        Activity activity;
        EditText password;

        HandleBrightness(Activity activity, EditText password) {
            this.activity = activity;
            this.password = password;
        }

        //Change brightness

        public void Brightness() {
            Handler handler = new Handler();
            handler.postDelayed(() -> {
                WindowManager.LayoutParams layout2 = activity.getWindow().getAttributes();
                layout2.screenBrightness = 0.2F;
                activity.getWindow().setAttributes(layout2);
            }, 0);
            handler.postDelayed(() -> {
                WindowManager.LayoutParams layout2 = activity.getWindow().getAttributes();
                layout2.screenBrightness = 0.9F;
                activity.getWindow().setAttributes(layout2);
            }, 300);
            handler.postDelayed(() -> {
                WindowManager.LayoutParams layout2 = activity.getWindow().getAttributes();
                layout2.screenBrightness = 0.2F;
                activity.getWindow().setAttributes(layout2);
            }, 600);
        }

        //Normal light
        public void handleDark() {
            Handler handler = new Handler();
            handler.postDelayed(() -> {
                WindowManager.LayoutParams layout2 = activity.getWindow().getAttributes();
                layout2.screenBrightness = 0.2F;
                activity.getWindow().setAttributes(layout2);
            }, 0);
        }

        public void handle(int val) {
            switch (val) {
                case 1:
                    Brightness();
                    break;
                default:
                    handleDark();
            }
        }
    }

