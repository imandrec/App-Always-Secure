package com.example.alwayssecure;

import java.util.Arrays;
//brightness 3-4-array 1
class imageOne extends MainActivity{

        String str = getPassword();
        String[] array = new String[4];
    void convertPasswordOneA() {
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //change pin
        String[] array = new String[4];
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //Pair 1
        String one = array[0];
        String first = one.substring(0,1);
        String second = one.substring(1,2);
        switch (first) {
            case "0":
                first = "5";
                array[0] = first;
                break;
            case "1":
                first = "2";
                array[0] = first;
                break;
            case "2":
                first = "8";
                array[0] = first;
                break;
            case "3":
                first = "3";
                array[0] = first;
                break;
            case "4":
                first = "1";
                array[0] = first;
                break;
            case "5":
                first = "0";
                array[0] = first;
                break;
            case "6":
                first = "9";
                array[0] = first;
                break;
            case "7":
                first = "4";
                array[0] = first;
                break;
            case "8":
                first = "7";
                array[0] = first;
                break;
            case "9":
                first = "6";
                array[0] = first;
                break;
            default:
                System.out.println("first number is not working");

        }
        switch (second) {
            case "0":
                second = "2";
                array[0] = array[0] + second;
                break;
            case "1":
                second = "6";
                array[0] = array[0] + second;
                break;
            case "2":
                second = "4";
                array[0] = array[0] + second;
                break;
            case "3":
                second = "0";
                array[0] = array[0] + second;
                break;
            case "4":
                second = "9";
                array[0] = array[0] + second;
                break;
            case "5":
                second = "3";
                array[0] = array[0] + second;
                break;
            case "6":
                second = "8";
                array[0] = array[0] + second;
                break;
            case "7":
                second = "1";
                array[0] = array[0] + second;
                break;
            case "8":
                second = "7";
                array[0] = array[0] + second;
                break;
            case "9":
                second = "5";
                array[0] = array[0] + second;
                break;
            default:
                System.out.println("second number is not working");
        }

        //Pair 2 is ignored because the brightness will change here

        //Pair 3
        String three = array[2];
        String tfirst = three.substring(0,1);
        String tsecond = three.substring(1,2);
        switch (tfirst) {
            case "0":
                tfirst = "5";
                array[2] = tfirst;
                break;
            case "1":
                tfirst = "2";
                array[2] = tfirst;
                break;
            case "2":
                tfirst = "8";
                array[2] = tfirst;
                break;
            case "3":
                tfirst = "3";
                array[2] = tfirst;
                break;
            case "4":
                tfirst = "1";
                array[2] = tfirst;
                break;
            case "5":
                tfirst = "0";
                array[2] = tfirst;
                break;
            case "6":
                tfirst = "9";
                array[2] = tfirst;
                break;
            case "7":
                tfirst = "4";
                array[2] = tfirst;
                break;
            case "8":
                tfirst = "7";
                array[2] = tfirst;
                break;
            case "9":
                tfirst = "6";
                array[2] = tfirst;
                break;
            default:
                System.out.println(" fifth number is not working");

        }
        switch (tsecond) {
            case "0":
                tsecond = "2";
                array[2] = array[2] + tsecond;
                break;
            case "1":
                tsecond = "6";
                array[2] = array[2] + tsecond;
                break;
            case "2":
                tsecond = "4";
                array[2] = array[2] + tsecond;
                break;
            case "3":
                tsecond = "0";
                array[2] = array[2] + tsecond;
                break;
            case "4":
                tsecond = "9";
                array[2] = array[2] + tsecond;
                break;
            case "5":
                tsecond = "3";
                array[2] = array[2] + tsecond;
                break;
            case "6":
                tsecond = "8";
                array[2] = array[2] + tsecond;
                break;
            case "7":
                tsecond = "1";
                array[2] = array[2] + tsecond;
                break;
            case "8":
                tsecond = "7";
                array[2] = array[2] + tsecond;
                break;
            case "9":
                tsecond = "5";
                array[2] = array[2] + tsecond;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Pair 4
        String four = array[3];
        String ffirst = four.substring(0,1);
        String fsecond = four.substring(1,2);
        switch (ffirst) {
            case "0":
                ffirst = "5";
                array[3] = ffirst;
                break;
            case "1":
                ffirst = "2";
                array[3] = ffirst;
                break;
            case "2":
                ffirst = "8";
                array[3] = ffirst;
                break;
            case "3":
                ffirst = "3";
                array[3] = ffirst;
                break;
            case "4":
                ffirst = "1";
                array[3] = ffirst;
                break;
            case "5":
                ffirst = "0";
                array[3] = ffirst;
                break;
            case "6":
                ffirst = "9";
                array[3] = ffirst;
                break;
            case "7":
                ffirst = "4";
                array[3] = ffirst;
                break;
            case "8":
                ffirst = "7";
                array[3] = ffirst;
                break;
            case "9":
                ffirst = "6";
                array[3] = ffirst;
                break;
            default:
                System.out.println("seventh number is not working");

        }
        switch (fsecond) {
            case "0":
                fsecond = "2";
                array[3] = array[3] + fsecond;
                break;
            case "1":
                fsecond = "6";
                array[3] = array[3] + fsecond;
                break;
            case "2":
                fsecond = "4";
                array[3] = array[3] + fsecond;
                break;
            case "3":
                fsecond = "0";
                array[3] = array[3] + fsecond;
                break;
            case "4":
                fsecond = "9";
                array[3] = array[3] + fsecond;
                break;
            case "5":
                fsecond = "3";
                array[3] = array[3] + fsecond;
                break;
            case "6":
                fsecond = "8";
                array[3] = array[3] + fsecond;
                break;
            case "7":
                fsecond = "1";
                array[3] = array[3] + fsecond;
                break;
            case "8":
                fsecond = "7";
                array[3] = array[3] + fsecond;
                break;
            case "9":
                fsecond = "5";
                array[3] = array[3] + fsecond;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Delete second element in the array

        String[] arr_new = new String[array.length-1];
        int j=1;
        for(int i=0, k=0;i<array.length;i++){
            if(i!=j){
                arr_new[k]=array[i];
                k++;
            }
        }

        //Remove , [ ] & spaces
        String code = Arrays.toString(arr_new);
        password = code.replace("[","");
        password = password.replace("]","");
        password = password.replace(",","");
        password = password.replaceAll("\\s+", "");
        password = password;

    }

    //brightness 5-6-array 2
    void convertPasswordOneB() {
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //change pin
        String[] array = new String[4];
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //Pair 1
        String one = array[0];
        String first = one.substring(0,1);
        String second = one.substring(1,2);
        switch (first) {
            case "0":
                first = "5";
                array[0] = first;
                break;
            case "1":
                first = "2";
                array[0] = first;
                break;
            case "2":
                first = "8";
                array[0] = first;
                break;
            case "3":
                first = "3";
                array[0] = first;
                break;
            case "4":
                first = "1";
                array[0] = first;
                break;
            case "5":
                first = "0";
                array[0] = first;
                break;
            case "6":
                first = "9";
                array[0] = first;
                break;
            case "7":
                first = "4";
                array[0] = first;
                break;
            case "8":
                first = "7";
                array[0] = first;
                break;
            case "9":
                first = "6";
                array[0] = first;
                break;
            default:
                System.out.println("first number is not working");

        }
        switch (second) {
            case "0":
                second = "2";
                array[0] = array[0] + second;
                break;
            case "1":
                second = "6";
                array[0] = array[0] + second;
                break;
            case "2":
                second = "4";
                array[0] = array[0] + second;
                break;
            case "3":
                second = "0";
                array[0] = array[0] + second;
                break;
            case "4":
                second = "9";
                array[0] = array[0] + second;
                break;
            case "5":
                second = "3";
                array[0] = array[0] + second;
                break;
            case "6":
                second = "8";
                array[0] = array[0] + second;
                break;
            case "7":
                second = "1";
                array[0] = array[0] + second;
                break;
            case "8":
                second = "7";
                array[0] = array[0] + second;
                break;
            case "9":
                second = "5";
                array[0] = array[0] + second;
                break;
            default:
                System.out.println("second number is not working");
        }

        //Pair 2 is ignored because the brightness will change here

        //Pair 3
        String three = array[1];
        String tfirst = three.substring(0,1);
        String tsecond = three.substring(1,2);
        switch (tfirst) {
            case "0":
                tfirst = "5";
                array[1] = tfirst;
                break;
            case "1":
                tfirst = "2";
                array[1] = tfirst;
                break;
            case "2":
                tfirst = "8";
                array[1] = tfirst;
                break;
            case "3":
                tfirst = "3";
                array[1] = tfirst;
                break;
            case "4":
                tfirst = "1";
                array[1] = tfirst;
                break;
            case "5":
                tfirst = "0";
                array[1] = tfirst;
                break;
            case "6":
                tfirst = "9";
                array[1] = tfirst;
                break;
            case "7":
                tfirst = "4";
                array[1] = tfirst;
                break;
            case "8":
                tfirst = "7";
                array[1] = tfirst;
                break;
            case "9":
                tfirst = "6";
                array[1] = tfirst;
                break;
            default:
                System.out.println(" fifth number is not working");

        }
        switch (tsecond) {
            case "0":
                tsecond = "2";
                array[1] = array[1] + tsecond;
                break;
            case "1":
                tsecond = "6";
                array[1] = array[1] + tsecond;
                break;
            case "2":
                tsecond = "4";
                array[1] = array[1] + tsecond;
                break;
            case "3":
                tsecond = "0";
                array[1] = array[1] + tsecond;
                break;
            case "4":
                tsecond = "9";
                array[1] = array[1] + tsecond;
                break;
            case "5":
                tsecond = "3";
                array[1] = array[1] + tsecond;
                break;
            case "6":
                tsecond = "8";
                array[1] = array[1] + tsecond;
                break;
            case "7":
                tsecond = "1";
                array[1] = array[1] + tsecond;
                break;
            case "8":
                tsecond = "7";
                array[1] = array[1] + tsecond;
                break;
            case "9":
                tsecond = "5";
                array[1] = array[1] + tsecond;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Pair 4
        String four = array[3];
        String ffirst = four.substring(0,1);
        String fsecond = four.substring(1,2);
        switch (ffirst) {
            case "0":
                ffirst = "5";
                array[3] = ffirst;
                break;
            case "1":
                ffirst = "2";
                array[3] = ffirst;
                break;
            case "2":
                ffirst = "8";
                array[3] = ffirst;
                break;
            case "3":
                ffirst = "3";
                array[3] = ffirst;
                break;
            case "4":
                ffirst = "1";
                array[3] = ffirst;
                break;
            case "5":
                ffirst = "0";
                array[3] = ffirst;
                break;
            case "6":
                ffirst = "9";
                array[3] = ffirst;
                break;
            case "7":
                ffirst = "4";
                array[3] = ffirst;
                break;
            case "8":
                ffirst = "7";
                array[3] = ffirst;
                break;
            case "9":
                ffirst = "6";
                array[3] = ffirst;
                break;
            default:
                System.out.println("seventh number is not working");

        }
        switch (fsecond) {
            case "0":
                fsecond = "2";
                array[3] = array[3] + fsecond;
                break;
            case "1":
                fsecond = "6";
                array[3] = array[3] + fsecond;
                break;
            case "2":
                fsecond = "4";
                array[3] = array[3] + fsecond;
                break;
            case "3":
                fsecond = "0";
                array[3] = array[3] + fsecond;
                break;
            case "4":
                fsecond = "9";
                array[3] = array[3] + fsecond;
                break;
            case "5":
                fsecond = "3";
                array[3] = array[3] + fsecond;
                break;
            case "6":
                fsecond = "8";
                array[3] = array[3] + fsecond;
                break;
            case "7":
                fsecond = "1";
                array[3] = array[3] + fsecond;
                break;
            case "8":
                fsecond = "7";
                array[3] = array[3] + fsecond;
                break;
            case "9":
                fsecond = "5";
                array[3] = array[3] + fsecond;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Delete second element in the array

        String[] arr_new = new String[array.length-1];
        int j=2;
        for(int i=0, k=0;i<array.length;i++){
            if(i!=j){
                arr_new[k]=array[i];
                k++;
            }
        }

        //Remove , [ ] & spaces
        String code = Arrays.toString(arr_new);
        password = code.replace("[","");
        password = password.replace("]","");
        password = password.replace(",","");
        password = password.replaceAll("\\s+", "");
        password = password;

    }

    //brightness 7-8-array 3
    void convertPasswordOneC() {
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //change pin
        String[] array = new String[4];
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //Pair 1
        String one = array[0];
        String first = one.substring(0,1);
        String second = one.substring(1,2);
        switch (first) {
            case "0":
                first = "5";
                array[0] = first;
                break;
            case "1":
                first = "2";
                array[0] = first;
                break;
            case "2":
                first = "8";
                array[0] = first;
                break;
            case "3":
                first = "3";
                array[0] = first;
                break;
            case "4":
                first = "1";
                array[0] = first;
                break;
            case "5":
                first = "0";
                array[0] = first;
                break;
            case "6":
                first = "9";
                array[0] = first;
                break;
            case "7":
                first = "4";
                array[0] = first;
                break;
            case "8":
                first = "7";
                array[0] = first;
                break;
            case "9":
                first = "6";
                array[0] = first;
                break;
            default:
                System.out.println("first number is not working");

        }
        switch (second) {
            case "0":
                second = "2";
                array[0] = array[0] + second;
                break;
            case "1":
                second = "6";
                array[0] = array[0] + second;
                break;
            case "2":
                second = "4";
                array[0] = array[0] + second;
                break;
            case "3":
                second = "0";
                array[0] = array[0] + second;
                break;
            case "4":
                second = "9";
                array[0] = array[0] + second;
                break;
            case "5":
                second = "3";
                array[0] = array[0] + second;
                break;
            case "6":
                second = "8";
                array[0] = array[0] + second;
                break;
            case "7":
                second = "1";
                array[0] = array[0] + second;
                break;
            case "8":
                second = "7";
                array[0] = array[0] + second;
                break;
            case "9":
                second = "5";
                array[0] = array[0] + second;
                break;
            default:
                System.out.println("second number is not working");
        }

        //Pair 2 is ignored because the brightness will change here

        //Pair 3
        String three = array[2];
        String tfirst = three.substring(0,1);
        String tsecond = three.substring(1,2);
        switch (tfirst) {
            case "0":
                tfirst = "5";
                array[2] = tfirst;
                break;
            case "1":
                tfirst = "2";
                array[2] = tfirst;
                break;
            case "2":
                tfirst = "8";
                array[2] = tfirst;
                break;
            case "3":
                tfirst = "3";
                array[2] = tfirst;
                break;
            case "4":
                tfirst = "1";
                array[2] = tfirst;
                break;
            case "5":
                tfirst = "0";
                array[2] = tfirst;
                break;
            case "6":
                tfirst = "9";
                array[2] = tfirst;
                break;
            case "7":
                tfirst = "4";
                array[2] = tfirst;
                break;
            case "8":
                tfirst = "7";
                array[2] = tfirst;
                break;
            case "9":
                tfirst = "6";
                array[2] = tfirst;
                break;
            default:
                System.out.println(" fifth number is not working");

        }
        switch (tsecond) {
            case "0":
                tsecond = "2";
                array[2] = array[2] + tsecond;
                break;
            case "1":
                tsecond = "6";
                array[2] = array[2] + tsecond;
                break;
            case "2":
                tsecond = "4";
                array[2] = array[2] + tsecond;
                break;
            case "3":
                tsecond = "0";
                array[2] = array[2] + tsecond;
                break;
            case "4":
                tsecond = "9";
                array[2] = array[2] + tsecond;
                break;
            case "5":
                tsecond = "3";
                array[2] = array[2] + tsecond;
                break;
            case "6":
                tsecond = "8";
                array[2] = array[2] + tsecond;
                break;
            case "7":
                tsecond = "1";
                array[2] = array[2] + tsecond;
                break;
            case "8":
                tsecond = "7";
                array[2] = array[2] + tsecond;
                break;
            case "9":
                tsecond = "5";
                array[2] = array[2] + tsecond;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Pair 4
        String four = array[1];
        String ffirst = four.substring(0,1);
        String fsecond = four.substring(1,2);
        switch (ffirst) {
            case "0":
                ffirst = "5";
                array[1] = ffirst;
                break;
            case "1":
                ffirst = "2";
                array[1] = ffirst;
                break;
            case "2":
                ffirst = "8";
                array[1] = ffirst;
                break;
            case "3":
                ffirst = "3";
                array[1] = ffirst;
                break;
            case "4":
                ffirst = "1";
                array[1] = ffirst;
                break;
            case "5":
                ffirst = "0";
                array[1] = ffirst;
                break;
            case "6":
                ffirst = "9";
                array[1] = ffirst;
                break;
            case "7":
                ffirst = "4";
                array[1] = ffirst;
                break;
            case "8":
                ffirst = "7";
                array[1] = ffirst;
                break;
            case "9":
                ffirst = "6";
                array[1] = ffirst;
                break;
            default:
                System.out.println("seventh number is not working");

        }
        switch (fsecond) {
            case "0":
                fsecond = "2";
                array[1] = array[1] + fsecond;
                break;
            case "1":
                fsecond = "6";
                array[1] = array[1] + fsecond;
                break;
            case "2":
                fsecond = "4";
                array[1] = array[1] + fsecond;
                break;
            case "3":
                fsecond = "0";
                array[1] = array[1] + fsecond;
                break;
            case "4":
                fsecond = "9";
                array[1] = array[1] + fsecond;
                break;
            case "5":
                fsecond = "3";
                array[1] = array[1] + fsecond;
                break;
            case "6":
                fsecond = "8";
                array[1] = array[1] + fsecond;
                break;
            case "7":
                fsecond = "1";
                array[1] = array[1] + fsecond;
                break;
            case "8":
                fsecond = "7";
                array[1] = array[1] + fsecond;
                break;
            case "9":
                fsecond = "5";
                array[1] = array[1] + fsecond;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Delete second element in the array

        String[] arr_new = new String[array.length-1];
        int j=3;
        for(int i=0, k=0;i<array.length;i++){
            if(i!=j){
                arr_new[k]=array[i];
                k++;
            }
        }

        //Remove , [ ] & spaces
        String code = Arrays.toString(arr_new);
        password = code.replace("[","");
        password = password.replace("]","");
        password = password.replace(",","");
        password = password.replaceAll("\\s+", "");
        password = password;

    }

}
