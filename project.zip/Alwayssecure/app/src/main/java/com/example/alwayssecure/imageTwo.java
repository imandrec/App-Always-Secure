package com.example.alwayssecure;

import java.util.Arrays;

class imageTwo extends MainActivity{

    String str = getPassword();
    String[] array = new String[4];
    //brightness 3-4-array 1
    void convertPasswordTwoA() {
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //change pin
        String[] array = new String[4];
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //Pair 1
        String one = array[0];
        String first = one.substring(0,1);
        String second = one.substring(1,2);
        switch (first) {
            case "0":
                first = "5";
                array[0] = first;
                break;
            case "1":
                first = "2";
                array[0] = first;
                break;
            case "2":
                first = "6";
                array[0] = first;
                break;
            case "3":
                first = "9";
                array[0] = first;
                break;
            case "4":
                first = "3";
                array[0] = first;
                break;
            case "5":
                first = "8";
                array[0] = first;
                break;
            case "6":
                first = "7";
                array[0] = first;
                break;
            case "7":
                first = "4";
                array[0] = first;
                break;
            case "8":
                first = "0";
                array[0] = first;
                break;
            case "9":
                first = "1";
                array[0] = first;
                break;
            default:
                System.out.println("first number is not working");

        }
        switch (second) {
            case "0":
                second = "7";
                array[0] = array[0] + second;
                break;
            case "1":
                second = "9";
                array[0] = array[0] + second;
                break;
            case "2":
                second = "6";
                array[0] = array[0] + second;
                break;
            case "3":
                second = "4";
                array[0] = array[0] + second;
                break;
            case "4":
                second = "2";
                array[0] = array[0] + second;
                break;
            case "5":
                second = "3";
                array[0] = array[0] + second;
                break;
            case "6":
                second = "8";
                array[0] = array[0] + second;
                break;
            case "7":
                second = "1";
                array[0] = array[0] + second;
                break;
            case "8":
                second = "0";
                array[0] = array[0] + second;
                break;
            case "9":
                second = "5";
                array[0] = array[0] + second;
                break;
            default:
                System.out.println("second number is not working");
        }

        //Pair 2 is ignored because the brightness will change here

        //Pair 3
        String three = array[2];
        String tfirst = three.substring(0,1);
        String tsecond = three.substring(1,2);
        switch (tfirst) {
            case "0":
                first = "5";
                array[2] = first;
                break;
            case "1":
                first = "2";
                array[2] = first;
                break;
            case "2":
                first = "6";
                array[2] = first;
                break;
            case "3":
                first = "9";
                array[2] = first;
                break;
            case "4":
                first = "3";
                array[2] = first;
                break;
            case "5":
                first = "8";
                array[2] = first;
                break;
            case "6":
                first = "7";
                array[2] = first;
                break;
            case "7":
                first = "4";
                array[2] = first;
                break;
            case "8":
                first = "0";
                array[2] = first;
                break;
            case "9":
                first = "1";
                array[2] = first;
                break;
            default:
                System.out.println(" fifth number is not working");

        }
        switch (tsecond) {
            case "0":
                second = "7";
                array[2] = array[2] + second;
                break;
            case "1":
                second = "9";
                array[2] = array[2] + second;
                break;
            case "2":
                second = "6";
                array[2] = array[2] + second;
                break;
            case "3":
                second = "4";
                array[2] = array[2] + second;
                break;
            case "4":
                second = "2";
                array[2] = array[2] + second;
                break;
            case "5":
                second = "3";
                array[2] = array[2] + second;
                break;
            case "6":
                second = "8";
                array[2] = array[2] + second;
                break;
            case "7":
                second = "1";
                array[2] = array[2] + second;
                break;
            case "8":
                second = "0";
                array[2] = array[2] + second;
                break;
            case "9":
                second = "5";
                array[2] = array[2] + second;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Pair 4
        String four = array[3];
        String ffirst = four.substring(0,1);
        String fsecond = four.substring(1,2);
        switch (ffirst) {
            case "0":
                first = "5";
                array[3] = first;
                break;
            case "1":
                first = "2";
                array[3] = first;
                break;
            case "2":
                first = "6";
                array[3] = first;
                break;
            case "3":
                first = "9";
                array[3] = first;
                break;
            case "4":
                first = "3";
                array[3] = first;
                break;
            case "5":
                first = "8";
                array[3] = first;
                break;
            case "6":
                first = "7";
                array[3] = first;
                break;
            case "7":
                first = "4";
                array[3] = first;
                break;
            case "8":
                first = "0";
                array[3] = first;
                break;
            case "9":
                first = "1";
                array[3] = first;
                break;
            default:
                System.out.println("seventh number is not working");

        }
        switch (fsecond) {
            case "0":
                second = "7";
                array[3] = array[3] + second;
                break;
            case "1":
                second = "9";
                array[3] = array[3] + second;
                break;
            case "2":
                second = "6";
                array[3] = array[3] + second;
                break;
            case "3":
                second = "4";
                array[3] = array[3] + second;
                break;
            case "4":
                second = "2";
                array[3] = array[3] + second;
                break;
            case "5":
                second = "3";
                array[3] = array[3] + second;
                break;
            case "6":
                second = "8";
                array[3] = array[3] + second;
                break;
            case "7":
                second = "1";
                array[3] = array[3] + second;
                break;
            case "8":
                second = "0";
                array[3] = array[3] + second;
                break;
            case "9":
                second = "5";
                array[3] = array[3] + second;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Delete second element in the array

        String[] arr_new = new String[array.length-1];
        int j=1;
        for(int i=0, k=0;i<array.length;i++){
            if(i!=j){
                arr_new[k]=array[i];
                k++;
            }
        }

        //Remove , [ ] & spaces
        String code = Arrays.toString(arr_new);
        password = code.replace("[","");
        password = password.replace("]","");
        password = password.replace(",","");
        password = password.replaceAll("\\s+", "");
        password = password;

    }

    //brightness 5-6-array 2
    void convertPasswordTwoB() {
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //change pin
        String[] array = new String[4];
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //Pair 1
        String one = array[0];
        String first = one.substring(0,1);
        String second = one.substring(1,2);
        switch (first) {
            case "0":
                first = "5";
                array[0] = first;
                break;
            case "1":
                first = "2";
                array[0] = first;
                break;
            case "2":
                first = "6";
                array[0] = first;
                break;
            case "3":
                first = "9";
                array[0] = first;
                break;
            case "4":
                first = "3";
                array[0] = first;
                break;
            case "5":
                first = "8";
                array[0] = first;
                break;
            case "6":
                first = "7";
                array[0] = first;
                break;
            case "7":
                first = "4";
                array[0] = first;
                break;
            case "8":
                first = "0";
                array[0] = first;
                break;
            case "9":
                first = "1";
                array[0] = first;
                break;
            default:
                System.out.println("first number is not working");

        }
        switch (second) {
            case "0":
                second = "7";
                array[0] = array[0] + second;
                break;
            case "1":
                second = "9";
                array[0] = array[0] + second;
                break;
            case "2":
                second = "6";
                array[0] = array[0] + second;
                break;
            case "3":
                second = "4";
                array[0] = array[0] + second;
                break;
            case "4":
                second = "2";
                array[0] = array[0] + second;
                break;
            case "5":
                second = "3";
                array[0] = array[0] + second;
                break;
            case "6":
                second = "8";
                array[0] = array[0] + second;
                break;
            case "7":
                second = "1";
                array[0] = array[0] + second;
                break;
            case "8":
                second = "0";
                array[0] = array[0] + second;
                break;
            case "9":
                second = "5";
                array[0] = array[0] + second;
                break;
            default:
                System.out.println("second number is not working");
        }

        //Pair 2 is ignored because the brightness will change here

        //Pair 3
        String three = array[1];
        String tfirst = three.substring(0,1);
        String tsecond = three.substring(1,2);
        switch (tfirst) {
            case "0":
                first = "5";
                array[1] = first;
                break;
            case "1":
                first = "2";
                array[1] = first;
                break;
            case "2":
                first = "6";
                array[1] = first;
                break;
            case "3":
                first = "9";
                array[1] = first;
                break;
            case "4":
                first = "3";
                array[1] = first;
                break;
            case "5":
                first = "8";
                array[1] = first;
                break;
            case "6":
                first = "7";
                array[1] = first;
                break;
            case "7":
                first = "4";
                array[1] = first;
                break;
            case "8":
                first = "0";
                array[1] = first;
                break;
            case "9":
                first = "1";
                array[1] = first;
                break;
            default:
                System.out.println(" fifth number is not working");

        }
        switch (tsecond) {
            case "0":
                second = "7";
                array[1] = array[1] + second;
                break;
            case "1":
                second = "9";
                array[1] = array[1] + second;
                break;
            case "2":
                second = "6";
                array[1] = array[1] + second;
                break;
            case "3":
                second = "4";
                array[1] = array[1] + second;
                break;
            case "4":
                second = "2";
                array[1] = array[1] + second;
                break;
            case "5":
                second = "3";
                array[1] = array[1] + second;
                break;
            case "6":
                second = "8";
                array[1] = array[1] + second;
                break;
            case "7":
                second = "1";
                array[1] = array[1] + second;
                break;
            case "8":
                second = "0";
                array[1] = array[1] + second;
                break;
            case "9":
                second = "5";
                array[1] = array[1] + second;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Pair 4
        String four = array[3];
        String ffirst = four.substring(0,1);
        String fsecond = four.substring(1,2);
        switch (ffirst) {
            case "0":
                first = "5";
                array[3] = first;
                break;
            case "1":
                first = "2";
                array[3] = first;
                break;
            case "2":
                first = "6";
                array[3] = first;
                break;
            case "3":
                first = "9";
                array[3] = first;
                break;
            case "4":
                first = "3";
                array[3] = first;
                break;
            case "5":
                first = "8";
                array[3] = first;
                break;
            case "6":
                first = "7";
                array[3] = first;
                break;
            case "7":
                first = "4";
                array[3] = first;
                break;
            case "8":
                first = "0";
                array[3] = first;
                break;
            case "9":
                first = "1";
                array[3] = first;
                break;
            default:
                System.out.println("seventh number is not working");

        }
        switch (fsecond) {
            case "0":
                second = "7";
                array[3] = array[3] + second;
                break;
            case "1":
                second = "9";
                array[3] = array[3] + second;
                break;
            case "2":
                second = "6";
                array[3] = array[3] + second;
                break;
            case "3":
                second = "4";
                array[3] = array[3] + second;
                break;
            case "4":
                second = "2";
                array[3] = array[3] + second;
                break;
            case "5":
                second = "3";
                array[3] = array[3] + second;
                break;
            case "6":
                second = "8";
                array[3] = array[3] + second;
                break;
            case "7":
                second = "1";
                array[3] = array[3] + second;
                break;
            case "8":
                second = "0";
                array[3] = array[3] + second;
                break;
            case "9":
                second = "5";
                array[3] = array[3] + second;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Delete third element in the array

        String[] arr_new = new String[array.length-1];
        int j=2;
        for(int i=0, k=0;i<array.length;i++){
            if(i!=j){
                arr_new[k]=array[i];
                k++;
            }
        }

        //Remove , [ ] & spaces
        String code = Arrays.toString(arr_new);
        password = code.replace("[","");
        password = password.replace("]","");
        password = password.replace(",","");
        password = password.replaceAll("\\s+", "");
        password = password;

    }

    //brightness 7-8-array 3
    void convertPasswordTwoC() {
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //change pin
        String[] array = new String[4];
        array[0] = str.substring(0,2);
        array[1] = str.substring(2,4);
        array[2] = str.substring(4,6);
        array[3] = str.substring(6,8);

        //Pair 1
        String one = array[0];
        String first = one.substring(0,1);
        String second = one.substring(1,2);
        switch (first) {
            case "0":
                first = "5";
                array[0] = first;
                break;
            case "1":
                first = "2";
                array[0] = first;
                break;
            case "2":
                first = "6";
                array[0] = first;
                break;
            case "3":
                first = "9";
                array[0] = first;
                break;
            case "4":
                first = "3";
                array[0] = first;
                break;
            case "5":
                first = "8";
                array[0] = first;
                break;
            case "6":
                first = "7";
                array[0] = first;
                break;
            case "7":
                first = "4";
                array[0] = first;
                break;
            case "8":
                first = "0";
                array[0] = first;
                break;
            case "9":
                first = "1";
                array[0] = first;
                break;
            default:
                System.out.println("first number is not working");

        }
        switch (second) {
            case "0":
                second = "7";
                array[0] = array[0] + second;
                break;
            case "1":
                second = "9";
                array[0] = array[0] + second;
                break;
            case "2":
                second = "6";
                array[0] = array[0] + second;
                break;
            case "3":
                second = "4";
                array[0] = array[0] + second;
                break;
            case "4":
                second = "2";
                array[0] = array[0] + second;
                break;
            case "5":
                second = "3";
                array[0] = array[0] + second;
                break;
            case "6":
                second = "8";
                array[0] = array[0] + second;
                break;
            case "7":
                second = "1";
                array[0] = array[0] + second;
                break;
            case "8":
                second = "0";
                array[0] = array[0] + second;
                break;
            case "9":
                second = "5";
                array[0] = array[0] + second;
                break;
            default:
                System.out.println("second number is not working");
        }

        //Pair 2 is ignored because the brightness will change here

        //Pair 3
        String three = array[2];
        String tfirst = three.substring(0,1);
        String tsecond = three.substring(1,2);
        switch (tfirst) {
            case "0":
                first = "5";
                array[2] = first;
                break;
            case "1":
                first = "2";
                array[2] = first;
                break;
            case "2":
                first = "6";
                array[2] = first;
                break;
            case "3":
                first = "9";
                array[2] = first;
                break;
            case "4":
                first = "3";
                array[2] = first;
                break;
            case "5":
                first = "8";
                array[2] = first;
                break;
            case "6":
                first = "7";
                array[2] = first;
                break;
            case "7":
                first = "4";
                array[2] = first;
                break;
            case "8":
                first = "0";
                array[2] = first;
                break;
            case "9":
                first = "1";
                array[2] = first;
                break;
            default:
                System.out.println(" fifth number is not working");

        }
        switch (tsecond) {
            case "0":
                second = "7";
                array[2] = array[2] + second;
                break;
            case "1":
                second = "9";
                array[2] = array[2] + second;
                break;
            case "2":
                second = "6";
                array[2] = array[2] + second;
                break;
            case "3":
                second = "4";
                array[2] = array[2] + second;
                break;
            case "4":
                second = "2";
                array[2] = array[2] + second;
                break;
            case "5":
                second = "3";
                array[2] = array[2] + second;
                break;
            case "6":
                second = "8";
                array[2] = array[2] + second;
                break;
            case "7":
                second = "1";
                array[2] = array[2] + second;
                break;
            case "8":
                second = "0";
                array[2] = array[2] + second;
                break;
            case "9":
                second = "5";
                array[2] = array[2] + second;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Pair 4
        String four = array[1];
        String ffirst = four.substring(0,1);
        String fsecond = four.substring(1,2);
        switch (ffirst) {
            case "0":
                first = "5";
                array[1] = first;
                break;
            case "1":
                first = "2";
                array[1] = first;
                break;
            case "2":
                first = "6";
                array[1] = first;
                break;
            case "3":
                first = "9";
                array[1] = first;
                break;
            case "4":
                first = "3";
                array[1] = first;
                break;
            case "5":
                first = "8";
                array[1] = first;
                break;
            case "6":
                first = "7";
                array[1] = first;
                break;
            case "7":
                first = "4";
                array[1] = first;
                break;
            case "8":
                first = "0";
                array[1] = first;
                break;
            case "9":
                first = "1";
                array[1] = first;
                break;
            default:
                System.out.println("seventh number is not working");

        }
        switch (fsecond) {
            case "0":
                second = "7";
                array[1] = array[1] + second;
                break;
            case "1":
                second = "9";
                array[1] = array[1] + second;
                break;
            case "2":
                second = "6";
                array[1] = array[1] + second;
                break;
            case "3":
                second = "4";
                array[1] = array[1] + second;
                break;
            case "4":
                second = "2";
                array[1] = array[1] + second;
                break;
            case "5":
                second = "3";
                array[1] = array[1] + second;
                break;
            case "6":
                second = "8";
                array[1] = array[1] + second;
                break;
            case "7":
                second = "1";
                array[1] = array[1] + second;
                break;
            case "8":
                second = "0";
                array[1] = array[1] + second;
                break;
            case "9":
                second = "5";
                array[1] = array[1] + second;
                break;
            default:
                System.out.println("sixth number is not working");
        }

        //Delete second element in the array

        String[] arr_new = new String[array.length-1];
        int j=3;
        for(int i=0, k=0;i<array.length;i++){
            if(i!=j){
                arr_new[k]=array[i];
                k++;
            }
        }

        //Remove , [ ] & spaces
        String code = Arrays.toString(arr_new);
        password = code.replace("[","");
        password = password.replace("]","");
        password = password.replace(",","");
        password = password.replaceAll("\\s+", "");
        password = password;

    }

}