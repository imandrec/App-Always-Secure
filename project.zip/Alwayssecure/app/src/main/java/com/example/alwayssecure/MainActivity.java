package com.example.alwayssecure;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    //Show random Matrix
    String nameImage;

    public void generatePicture() {
        List<Integer> Imagenes = new ArrayList<Integer>();
        Imagenes.add(R.drawable.matrix1);
        Imagenes.add(R.drawable.matrix2);
        Imagenes.add(R.drawable.matrix3);
        Imagenes.add(R.drawable.matrix4);
        Imagenes.add(R.drawable.matrix5);
        Imagenes.add(R.drawable.matrix6);
        Imagenes.add(R.drawable.matrix7);
        Imagenes.add(R.drawable.matrix8);
        Imagenes.add(R.drawable.matrix9);
        //Imagenes.add(R.drawable.matrix4);
        //Imagenes.add(R.drawable.matrix5);

        Collections.shuffle(Imagenes);
        Random r = new Random();
        int rndInt = r.nextInt(9) + 1;
        String imgName = "matrix" + rndInt;
        int id = getResources().getIdentifier(imgName, "drawable", getPackageName());
        try {
            imageView.setImageResource(id);

        } catch (Exception e) {
            imageView.setImageResource(R.drawable.img);

        }
        nameImage = imgName;
    }

    String lieSequence1 = "00110000";
    String lieSequence2 = "00001100";
    String lieSequence3 = "00000011";
    static public String email, password;

    private final Activity activity = this;

    private EditText passwordEditText;
    private TextView sample;

    //Authentication
    private EditText editTextEmail, editTextPassword;
    private Button signIn;

    private FirebaseAuth mAuth;

    //Register & forgot password
    private ImageView imageView;
    private TextView register, forgotPassword;

    String getPassword() {
        return password;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView) findViewById(R.id.imageView);
        generatePicture();

        imageView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                generatePicture();
            }
        });

        //authentication
        signIn = (Button) findViewById(R.id.signIn);
        signIn.setOnClickListener(this);
        editTextEmail = (EditText) findViewById(R.id.email);
        editTextPassword = (EditText) findViewById(R.id.PasswordEditText);
        mAuth = FirebaseAuth.getInstance();

        //register
        register = (TextView) findViewById(R.id.register);
        register.setOnClickListener(this);

        //forgot password
        forgotPassword = (TextView) findViewById(R.id.forgotPassword);
        forgotPassword.setOnClickListener(this);

        passwordEditText = findViewById(R.id.PasswordEditText);
        Handler handler = new Handler();
        passwordEditText.setFocusable(true);
        handler.postDelayed(() -> {
            final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
            handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence1.charAt(0))));
        }, 1000);
        passwordEditText.addTextChangedListener(textWatcher);
    }



    private TextWatcher textWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String passwordEntered = passwordEditText.getText().toString();

            final int idx = passwordEntered.length();
            if (idx >= 8) {
                passwordEditText.setError("Max password length should be 8 characters!");
                passwordEditText.requestFocus();
            } else {
                if (nameImage.equals("matrix1")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence1.charAt(idx))));
                } else if (nameImage.equals("matrix2")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence2.charAt(idx))));
                } else if (nameImage.equals("matrix3")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence3.charAt(idx))));
                } else if (nameImage.equals("matrix4")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence1.charAt(idx))));
                } else if (nameImage.equals("matrix5")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence2.charAt(idx))));
                } else if (nameImage.equals("matrix6")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence3.charAt(idx))));
                } else if (nameImage.equals("matrix7")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence1.charAt(idx))));
                } else if (nameImage.equals("matrix8")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence2.charAt(idx))));
                } else if (nameImage.equals("matrix9")) {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence3.charAt(idx))));
                } else {
                    final HandleBrightness handleBrightness = new HandleBrightness(activity, passwordEditText);
                    handleBrightness.handle(Integer.parseInt(String.valueOf(lieSequence2.charAt(idx))));
                }
            }
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    //open register & forget password
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.register:
                startActivity(new Intent(this, RegisterUser.class));
                break;

            //open forgot password window
            case R.id.forgotPassword:
                startActivity(new Intent(this, ForgotPassword.class));
                break;

            //authentication
            case R.id.signIn:
                userLogin();
                break;

        }
    }

    void userLogin() {
        email = editTextEmail.getText().toString().trim();
        password = editTextPassword.getText().toString().trim();


        if (email.isEmpty()) {
            editTextEmail.setError("Email is required!");
            editTextEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please provide a valid email!");
            editTextEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required!");
            editTextPassword.requestFocus();
            return;
        }



        //change number before sending to firebase
        if (nameImage.equals("matrix1")) {
            imageOne imageObjectOneA = new imageOne();
            imageObjectOneA.convertPasswordOneA();
        } else if (nameImage.equals("matrix2")) {
            imageOne imageObjectOneB = new imageOne();
            imageObjectOneB.convertPasswordOneB();
        } else if (nameImage.equals("matrix3")) {
            imageOne imageObjectOneC = new imageOne();
            imageObjectOneC.convertPasswordOneC();
        } else if (nameImage.equals("matrix4")) {
            imageTwo imageObjectTwoA = new imageTwo();
            imageObjectTwoA.convertPasswordTwoA();
        } else if (nameImage.equals("matrix5")) {
            imageTwo imageObjectTwoB = new imageTwo();
            imageObjectTwoB.convertPasswordTwoB();
        } else if (nameImage.equals("matrix6")) {
            imageTwo imageObjectTwoC = new imageTwo();
            imageObjectTwoC.convertPasswordTwoC();
        } else if (nameImage.equals("matrix7")) {
            imageThree imageObjectThreeA = new imageThree();
            imageObjectThreeA.convertPasswordThreeA();
        } else if (nameImage.equals("matrix8")) {
            imageThree imageObjectThreeB = new imageThree();
            imageObjectThreeB.convertPasswordThreeB();
        } else if (nameImage.equals("matrix9")) {
            imageThree imageObjectThreeC = new imageThree();
            imageObjectThreeC.convertPasswordThreeC();
        }


            //Send password to Firebase
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to login! Please try again", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

    }

